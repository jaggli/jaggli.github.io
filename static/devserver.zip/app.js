const express = require("express");
const path = require("path");
const favicon = require("serve-favicon");
const logger = require("morgan");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const program = require("./cmd");
const listing = require("./views/listing");
const serveIndex = require('serve-index');
const app = express();
const pkg = require('./package.json')

// setup view
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");
app.use(logger("dev"));

// directory listing
app.use(function(req, res, next){
  req.method = 'GET' //handle everything as a GET request
  res.setHeader('X-Powered-By', `${pkg.name} v${pkg.version}`)
  next()
})
app.use(express.static(path.join(__dirname, "public")));
app.use( serveIndex( program.directory, listing))

// static serving directory
app.use( express.static( program.directory, {
  dotfiles: !!program.all? "allow" : "ignore",
  etag: !!program.cacheHeaders,
  maxage: !!program.cacheHeaders? (24 * 60 * 60 * 1000) : -1
}))

// 404
app.use(function(req, res, next) {
  let err = new Error("Not Found");
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};
  res.status(err.status || 500);
  res.render("error");
});

module.exports = app;
