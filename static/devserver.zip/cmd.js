const pkg = require("./package")
const program = require("commander")
const path = require("path")

program
  .version( pkg.version )
  .usage("[options] <dir>")
  .on('--help', function(){ console.log([
      "  Examples:",
      "",
      "    Start a server in the current directory:",
      "    $ devserver",
      "",
      "    With options:",
      "    $ devserver -p 3000 -a -c ~/development"
  ].join("\n")) })
  .option("-p, --port <n>", "Server port, default: 8080", parseInt)
  .option("-c, --cache-headers", "Use client side caching, disabled by default")
  .option("-a, --all", "Show hidden files, disabled by default")
  .parse(process.argv);

program.directory = path.resolve( program.args.shift() || process.cwd() );

module.exports = program