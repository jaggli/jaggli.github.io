# Simple http server 
With directory listing and no-cache headers for development

## Installation
```bash
sudo npm install -g @s24/devserver
```

## Usage
Starting a server in a specific directory is dead simple. Just run the `devserver` command and go to [localhost:8080](http://localhost:8080)
```bash
devserver
```

### Options
```
-a, --all            Show hidden files, disabled by default
-c, --cache-headers  Use client side caching, disabled by default
-h, --help           Output usage information
-p, --port <n>       Server port, default: 8080
-V, --version        Output the version number
```

