const jade = require("jade");
const path = require("path");
const fs = require("fs");
const filesize = require("../lib/filesize")
const program = require("../cmd")
const lz = function lz(n){ return ("00"+n).slice(-2) }

const processFileList = function processFileList( fileList, fileDir, filePath ){
  return fileList
    .filter(function(item){ return item.name !== ".." })
    .map(function(item){

      let stats = fs.statSync(path.join(filePath, item.name));
      item.isDirectory = stats.isDirectory();

      item.href = path.join( fileDir, item.name)
      if(item.isDirectory && item.href !== "/" ){
        item.href += "/"
      }

      item.size = item.isDirectory? "" : filesize( stats.size )

      let date = new Date(stats.birthtime)
      item.date =
        lz( date.getDate() ) +"."+ 
        lz( date.getMonth() + 1 ) +"."+ 
        date.getFullYear() +", "+
        lz( date.getHours() ) +":"+
        lz( date.getMinutes() );

      item.icon = "file";
      if(item.isDirectory){
        item.icon = "folder-open"
      }

      return item;
    })
}

module.exports = { 
  icons: true,
  view: "details",
  stylesheet: false,
  hidden: !!program.all,
  template: function(locals, callback){

    locals.fileList = processFileList( locals.fileList, locals.directory, locals.path )

    locals.directories = locals.directory
      .replace(/\/+$/, "")
      .split("/")
      .map(function(name, i, names){

        let href = names.slice(0, i+1).join("/") || "/";
        if(i === names.length-1){ href = ""; }

        return { href, name }
      })

    locals.directoryName = locals.directories.slice(-1).pop().name || "Home"
    locals.title = locals.directoryName

    let html = jade.compileFile( path.join(__dirname, "listing.jade"), {} )(locals)
    callback(null, html);
  }
}
